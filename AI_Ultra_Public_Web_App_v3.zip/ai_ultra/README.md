# AI Ultra — public web app + AI Game Studio (v3)

AI Ultra is an editable web application with an AI chat workspace and a browser-game generator. It is a project you can host and customise; it is **not a clone of ChatGPT Pro** and does not include OpenAI's private models, tools, or subscription entitlements. Its intelligence and some capabilities depend on the AI provider you connect.

## What's in this version

- AI chat through an OpenAI-compatible chat-completions endpoint
- Local Ollama support for development, or a hosted compatible endpoint for a public website
- Model selector, conversation history, import/export, custom instructions and saved browser memory
- Text/code/CSV/JSON/PDF/image attachments (PDF extraction uses pypdf; image understanding needs a vision model)
- Optional Tavily web search and compatible image-generation endpoint
- Browser speech input and read-aloud where supported
- **Game Studio:** describe an original browser game, generate editable HTML/CSS/JavaScript project files, preview the game in an isolated frame, copy source and download a ZIP
- Android Capacitor wrapper starter and Google Play preparation guide
- Render deployment blueprint and Dockerfile

## Run locally

Requires Python 3.10+. The app server uses Python's standard library; `pypdf` is installed for PDF text extraction.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

For a local Ollama model, install Ollama and run:

```bash
ollama pull qwen2.5:7b
```

Then start the app:

```bash
# macOS/Linux
AI_ULTRA_API_BASE=http://127.0.0.1:11434/v1 COOKIE_SECURE=false python server.py
# Windows PowerShell
$env:AI_ULTRA_API_BASE="http://127.0.0.1:11434/v1"; $env:COOKIE_SECURE="false"; python server.py
```

Open http://127.0.0.1:8000. For local development, `AI_ULTRA_ACCESS_PASSWORD` may be left unset. If you set it, the app displays a sign-in screen.

## Publish the website

A deployment blueprint is included as `render.yaml`. It starts the standard-library server with `python server.py`.

1. Put this project in a Git repository you control.
2. Create a web service from that repository in your hosting provider (the included blueprint targets Render).
3. Set these environment variables in the host dashboard:
   - `FLASK_SECRET_KEY`: a long random secret (Render blueprint can generate it).
   - `AI_ULTRA_ACCESS_PASSWORD`: set a strong private access password. Do not leave it blank on a public deployment.
   - `AI_ULTRA_API_BASE`: HTTPS base URL of an OpenAI-compatible provider. A local `127.0.0.1` Ollama address will **not** work from a cloud host.
   - `AI_ULTRA_API_KEY`: provider key, if required. Keep it in the host's secret environment settings; never put it in frontend JavaScript or commit it to Git.
   - `AI_ULTRA_MODEL`: a model ID supported by that provider.
   - Optional `TAVILY_API_KEY` and `AI_ULTRA_IMAGE_MODEL` for web search and image generation.
4. Deploy. The host gives you a temporary public URL. You can connect a domain you own through the host's domain settings; buying/registering a custom domain is separate.
5. Test sign-in, chat, Game Studio, downloads, mobile layout and provider usage limits before sharing the link.

**Important:** This starter uses a shared access password, not individual user accounts. Do not open it to the public without adding proper account management, stronger abuse prevention, privacy/terms pages, and a production security review. A public AI endpoint can create provider charges. Keep the access password enabled and API keys private. Free hosting plans may sleep, limit resources, or be unsuitable for long game-generation requests.

## Game Studio workflow

1. Open **Game studio** in AI Ultra.
2. Describe the game, its controls, goal, levels, visual style and win/lose conditions.
3. Select a model that can follow structured JSON instructions and create code.
4. Click **Create playable game**. The app requests project source files from the connected model.
5. Try the preview, inspect/copy source files, then download the ZIP.
6. Extract the ZIP and open `index.html` to test it. For projects that load local files, use a local development server rather than opening the file directly.

Generated code is a starting point, not a guarantee of a finished, bug-free or store-compliant game. Test it on the devices you intend to support. Review all generated assets and code for licensing, safety, privacy and quality before publishing.

## Publish a game on the web

Upload the extracted game's files to a static web host (or add them to a website project). Test the public URL on desktop and mobile. If the game uses online accounts, multiplayer, payments or saved cloud progress, it needs additional backend services and security work; a standalone HTML export does not provide those automatically.

## Prepare an Android game for Google Play

The `android-wrapper/` folder is a Capacitor starter. It is **not** a signed Android App Bundle and does not upload to Google Play automatically.

1. Install Node.js and Android Studio on a computer.
2. Copy the extracted game's web files into `android-wrapper/www/`, keeping relative paths.
3. Change `appId` in `android-wrapper/capacitor.config.json` to a unique package ID and set the app name.
4. In `android-wrapper/`, run `npm install`, `npx cap add android`, `npx cap sync android`, then `npx cap open android`.
5. Test and refine the Android build. Use Android Studio's signed release workflow to produce an Android App Bundle (`.aab`).
6. Complete the current Play Console listing, declarations, content rating, data-safety/privacy information, testing and review steps, then upload the signed AAB.

Google Play requires new apps to use Android App Bundles. A Play Console developer account requires the account holder to be at least 18; Google's current help page also lists a one-time US$25 registration fee and identity verification. If you are under 18, an adult who is eligible must handle the developer account and publishing responsibilities—do not misstate your age or bypass the checks. See the official requirements: https://support.google.com/googleplay/android-developer/answer/6112435 and https://support.google.com/googleplay/android-developer/answer/9859152.

## Customise the app

- `static/index.html` — pages, navigation and content
- `static/styles.css` — colours, typography, spacing and layout
- `static/app.js` — browser behaviour and interactions
- `server.py` — backend routes and AI provider connections
- `render.yaml`, `Dockerfile`, `Procfile` — deployment configuration
- `android-wrapper/` — Android packaging starter for browser games

You can change the product name and visual identity in the HTML/CSS. Keep secrets and provider keys in server environment variables, never in `static/app.js`.

## Known limitations

- Not equivalent to ChatGPT Pro; no private OpenAI models or guaranteed feature parity.
- AI provider must support chat completions. Game generation works best with a model that reliably follows JSON output instructions.
- Game Studio creates browser-game source projects. It does not currently create native Unity/Unreal projects, build signed AABs automatically, or publish directly to Google Play.
- Multiplayer, cloud saves, user accounts, payments, analytics and moderation are not included by default.
- Web search, image generation and vision depend on configured providers/models and may incur charges.
- Browser history and saved memory are stored locally in each browser, not synchronised across devices.

## Privacy and security

Messages and attachments are sent to the AI provider you configure. Search requests are sent to Tavily when enabled. Do not enter passwords, payment information, private keys or sensitive personal data. Before operating a public service, add a privacy policy, terms, account controls, abuse monitoring and a security review.
