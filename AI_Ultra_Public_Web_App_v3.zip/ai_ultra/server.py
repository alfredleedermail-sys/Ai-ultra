#!/usr/bin/env python3
"""AI Ultra v3 web app. Standard-library HTTP server; optional pypdf for PDFs."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse
from pathlib import Path
import base64, json, os, re, urllib.request, urllib.error, mimetypes, uuid, io, zipfile, hmac, hashlib, http.cookies

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
GENERATED = STATIC / "generated"
GENERATED.mkdir(exist_ok=True)
HOST = os.environ.get("AI_ULTRA_HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", os.environ.get("AI_ULTRA_PORT", "8000")))
API_BASE = os.environ.get("AI_ULTRA_API_BASE", "http://127.0.0.1:11434/v1").rstrip("/")
API_KEY = os.environ.get("AI_ULTRA_API_KEY", "")
DEFAULT_MODEL = os.environ.get("AI_ULTRA_MODEL", "qwen2.5:7b")
IMAGE_MODEL = os.environ.get("AI_ULTRA_IMAGE_MODEL", "")
TAVILY_API_KEY = os.environ.get("TAVILY_API_KEY", "")
ACCESS_PASSWORD = os.environ.get("AI_ULTRA_ACCESS_PASSWORD", "")
SESSION_SECRET = os.environ.get("FLASK_SECRET_KEY", "local-development-secret-change-before-deploy").encode("utf-8")
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "true").lower() == "true"

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC), **kwargs)

    def _json(self, status, data):
        raw = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _authorized(self):
        if not ACCESS_PASSWORD: return True
        cookie = http.cookies.SimpleCookie(self.headers.get("Cookie", ""))
        morsel = cookie.get("ai_ultra_session")
        expected = hmac.new(SESSION_SECRET, b"ai-ultra-authenticated", hashlib.sha256).hexdigest()
        return bool(morsel and hmac.compare_digest(morsel.value, expected))

    def _require_auth(self):
        if self._authorized(): return True
        self._json(401, {"error": "Please sign in to AI Ultra."})
        return False

    def _binary(self, status, data, content_type, filename):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _read_payload(self, limit=12_000_000):
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > limit:
            raise ValueError("Request is empty or too large.")
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def _provider_request(self, path, payload, timeout=180):
        req = urllib.request.Request(API_BASE + path, data=json.dumps(payload).encode(), method="POST")
        req.add_header("Content-Type", "application/json")
        if API_KEY:
            req.add_header("Authorization", "Bearer " + API_KEY)
        with urllib.request.urlopen(req, timeout=timeout) as res:
            return json.loads(res.read().decode("utf-8"))

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/status":
            self._json(200, {
                "provider": "OpenAI-compatible", "api_base": API_BASE, "model": DEFAULT_MODEL,
                "configured_key": bool(API_KEY), "local_default": API_BASE.startswith(("http://127.0.0.1", "http://localhost")),
                "web_search": bool(TAVILY_API_KEY), "image_generation": bool(IMAGE_MODEL),
                "pdf_support": self._has_pdf_support(), "game_studio": True,
                "password_required": bool(ACCESS_PASSWORD), "authenticated": self._authorized()
            }); return
        public_files = {"/", "/index.html", "/styles.css", "/app.js", "/favicon.ico"}
        if path not in public_files and not self._require_auth(): return
        if path == "/api/models":
            try:
                req = urllib.request.Request(API_BASE + "/models")
                if API_KEY: req.add_header("Authorization", "Bearer " + API_KEY)
                with urllib.request.urlopen(req, timeout=8) as res: data = json.loads(res.read().decode())
                self._json(200, {"models": [m.get("id") for m in data.get("data", []) if m.get("id")], "default": DEFAULT_MODEL})
            except Exception as exc: self._json(200, {"models": [], "default": DEFAULT_MODEL, "note": str(exc)})
            return
        return super().do_GET()

    @staticmethod
    def _has_pdf_support():
        try: import pypdf; return True
        except ImportError: return False

    def do_POST(self):
        path = urlparse(self.path).path
        try:
            if path == "/api/login":
                payload = self._read_payload(100_000)
                if not ACCESS_PASSWORD or hmac.compare_digest(str(payload.get("password", "")), ACCESS_PASSWORD):
                    token = hmac.new(SESSION_SECRET, b"ai-ultra-authenticated", hashlib.sha256).hexdigest()
                    self.send_response(200)
                    cookie = f"ai_ultra_session={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=1209600"
                    if COOKIE_SECURE: cookie += "; Secure"
                    self.send_header("Set-Cookie", cookie)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", "11")
                    self.end_headers(); self.wfile.write(b'{"ok":true}')
                    return
                return self._json(401, {"error": "That access password is not correct."})
            if not self._require_auth(): return
            if path == "/api/chat":
                payload = self._read_payload()
                messages = payload.get("messages", [])
                if not isinstance(messages, list) or not messages: return self._json(400, {"error": "Please provide at least one message."})
                safe = []
                for msg in messages[-50:]:
                    role, content = msg.get("role"), msg.get("content")
                    if role not in ("system", "user", "assistant"): continue
                    if isinstance(content, str): content = content[:100000]
                    elif isinstance(content, list):
                        parts = []
                        for part in content[:8]:
                            if not isinstance(part, dict): continue
                            if part.get("type") == "text": parts.append({"type":"text", "text":str(part.get("text", ""))[:60000]})
                            elif part.get("type") == "image_url":
                                url = part.get("image_url", {}).get("url", "")
                                if isinstance(url, str) and url.startswith("data:image/") and len(url) < 8_000_000:
                                    parts.append({"type":"image_url", "image_url":{"url":url}})
                        content = parts
                    else: continue
                    safe.append({"role": role, "content": content})
                model = str(payload.get("model") or DEFAULT_MODEL)[:150]
                body = {"model":model,"messages":safe,"temperature":max(0,min(2,float(payload.get("temperature",0.7)))),"stream":False}
                result = self._provider_request("/chat/completions", body)
                answer = result["choices"][0]["message"]["content"]
                if isinstance(answer, list): answer = "\n".join(p.get("text", "") for p in answer if isinstance(p, dict))
                return self._json(200, {"reply":str(answer),"model":model})
            if path == "/api/search":
                payload = self._read_payload(100_000); query = str(payload.get("query", "")).strip()[:500]
                if not TAVILY_API_KEY: return self._json(503, {"error":"Web search is not configured. Add TAVILY_API_KEY to enable it."})
                req = urllib.request.Request("https://api.tavily.com/search", data=json.dumps({"api_key":TAVILY_API_KEY,"query":query,"search_depth":"basic","max_results":5,"include_answer":True}).encode(), headers={"Content-Type":"application/json"}, method="POST")
                with urllib.request.urlopen(req, timeout=25) as res: data=json.loads(res.read().decode())
                return self._json(200, {"answer":data.get("answer", ""),"results":[{"title":x.get("title",""),"url":x.get("url",""),"content":x.get("content","")} for x in data.get("results",[])]})
            if path == "/api/extract-pdf":
                payload = self._read_payload(12_000_000)
                raw = base64.b64decode(payload.get("data", ""), validate=True)
                try:
                    from pypdf import PdfReader
                    reader=PdfReader(io.BytesIO(raw)); text="\n\n".join((p.extract_text() or "") for p in reader.pages[:80])
                    return self._json(200,{"text":text[:100000],"pages":len(reader.pages)})
                except ImportError: return self._json(501,{"error":"PDF text extraction needs pypdf. Install it with: python -m pip install -r requirements.txt"})
            if path == "/api/image":
                payload = self._read_payload(100_000)
                if not IMAGE_MODEL: return self._json(503,{"error":"Image generation is not configured. Set AI_ULTRA_IMAGE_MODEL and use a provider that supports /images/generations."})
                prompt=str(payload.get("prompt", "")).strip()[:4000]
                req_data={"model":IMAGE_MODEL,"prompt":prompt,"n":1,"size":"1024x1024"}
                req=urllib.request.Request(API_BASE+"/images/generations",data=json.dumps(req_data).encode(),headers={"Content-Type":"application/json"},method="POST")
                if API_KEY: req.add_header("Authorization","Bearer "+API_KEY)
                with urllib.request.urlopen(req,timeout=180) as res: data=json.loads(res.read().decode())
                item=data.get("data", [{}])[0]
                if item.get("url"): url=item["url"]
                elif item.get("b64_json"):
                    blob=base64.b64decode(item["b64_json"]); ext=".png"; name=uuid.uuid4().hex+ext
                    (GENERATED/name).write_bytes(blob); url="/generated/"+name
                else: raise ValueError("Image provider returned no image URL or image data.")
                return self._json(200,{"url":url})
            if path == "/api/game/generate":
                payload = self._read_payload(100_000)
                brief = str(payload.get("prompt", "")).strip()[:7000]
                if len(brief) < 12: return self._json(400, {"error": "Describe the game you want in a little more detail."})
                game_system = """You are the game-development engine inside AI Ultra. Create a complete, original, playable browser game from the user's brief. Return ONLY valid JSON with this schema: {\"name\":\"short game title\",\"description\":\"one sentence\",\"files\":[{\"path\":\"index.html\",\"content\":\"complete HTML source\"},{\"path\":\"style.css\",\"content\":\"CSS source\"},{\"path\":\"game.js\",\"content\":\"JavaScript source\"}],\"instructions\":\"how to run\"}. Make a genuinely playable 2D game, not a mockup or screenshot. Use Canvas or DOM, keyboard and touch controls where sensible, clear start/restart, scoring or objectives, responsive layout, polished visual feedback and no external dependencies/CDNs. Keep files small and self-contained. The index.html must link to the other files using relative paths. Use original characters, names and artwork; do not copy existing games. Avoid graphic violence and dangerous real-world instructions. Return all source files in the JSON. Do not include markdown fences."""
                model = str(payload.get("model") or DEFAULT_MODEL)[:150]
                result = self._provider_request("/chat/completions", {"model": model, "temperature": 0.55, "stream": False, "response_format": {"type": "json_object"}, "messages": [{"role": "system", "content": game_system}, {"role": "user", "content": brief}]}, timeout=240)
                answer = result["choices"][0]["message"]["content"]
                if isinstance(answer, list): answer = "".join(p.get("text", "") for p in answer if isinstance(p, dict))
                answer = re.sub(r"^```(?:json)?\s*|\s*```$", "", str(answer).strip(), flags=re.I)
                parsed = json.loads(answer)
                files = parsed.get("files")
                if not isinstance(files, list) or not files: raise ValueError("The AI did not return a game file list. Try a more specific description.")
                clean, seen, total = [], set(), 0
                for item in files[:15]:
                    rel = str(item.get("path", "")).replace("\\", "/").strip()
                    content = item.get("content", "")
                    if not isinstance(content, str) or rel.startswith("/") or ".." in rel.split("/") or not re.fullmatch(r"[A-Za-z0-9._/-]{1,100}", rel) or rel in seen: continue
                    seen.add(rel); total += len(content.encode("utf-8"))
                    if total > 500_000: raise ValueError("Generated project is too large. Ask for a smaller game.")
                    clean.append({"path": rel, "content": content})
                if not any(f["path"] == "index.html" for f in clean): raise ValueError("Generated project is missing index.html. Please try again.")
                return self._json(200, {"name": str(parsed.get("name", "My AI Game"))[:80], "description": str(parsed.get("description", ""))[:400], "instructions": str(parsed.get("instructions", ""))[:1000], "files": clean})
            if path == "/api/game/export":
                payload = self._read_payload(1_000_000)
                files = payload.get("files", [])
                if not isinstance(files, list) or not files: raise ValueError("There are no game files to export.")
                name = re.sub(r"[^A-Za-z0-9_-]+", "_", str(payload.get("name", "AI_Ultra_Game")))[:50].strip("_") or "AI_Ultra_Game"
                mem = io.BytesIO(); seen = set(); total = 0
                with zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED) as archive:
                    for item in files[:15]:
                        rel = str(item.get("path", "")).replace("\\", "/").strip(); content = item.get("content", "")
                        if not isinstance(content, str) or rel.startswith("/") or ".." in rel.split("/") or not re.fullmatch(r"[A-Za-z0-9._/-]{1,100}", rel) or rel in seen: continue
                        seen.add(rel); total += len(content.encode("utf-8"))
                        if total > 500_000: raise ValueError("Project is too large to export.")
                        archive.writestr(name + "/" + rel, content)
                    if "index.html" not in seen: raise ValueError("Project is missing index.html.")
                    archive.writestr(name + "/README.txt", name + "\n\nOpen index.html in a browser to play. Review and test the code before publishing.\n")
                    archive.writestr(name + "/ANDROID_PUBLISHING_GUIDE.txt", "For Android packaging, see the android-wrapper folder in the full AI Ultra source project. A signed Android App Bundle and Play Console submission are separate steps.\n")
                return self._binary(200, mem.getvalue(), "application/zip", name + ".zip")
            if path == "/api/logout":
                self.send_response(200); self.send_header("Set-Cookie", "ai_ultra_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"); self.send_header("Content-Length", "11"); self.end_headers(); self.wfile.write(b'{"ok":true}'); return
            return self._json(404,{"error":"Not found"})
        except urllib.error.HTTPError as exc:
            detail=exc.read().decode("utf-8",errors="replace")[:2500]
            return self._json(502,{"error":f"Provider returned HTTP {exc.code}","detail":detail})
        except urllib.error.URLError as exc: return self._json(503,{"error":"Could not reach the configured service.","detail":str(exc.reason)})
        except ValueError as exc: return self._json(400,{"error":str(exc)})
        except Exception as exc: return self._json(500,{"error":"Unexpected server error","detail":str(exc)})

if __name__ == "__main__":
    print(f"AI Ultra running on {HOST}:{PORT}")
    print(f"AI endpoint: {API_BASE} (default model: {DEFAULT_MODEL})")
    if HOST == "0.0.0.0" and not ACCESS_PASSWORD:
        print("WARNING: public binding without AI_ULTRA_ACCESS_PASSWORD is unsafe.")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
