ANDROID WRAPPER STARTER (NOT A READY-TO-PUBLISH APP BUNDLE)

This folder is a starter for packaging a browser game as an Android app with Capacitor.
It does not automatically sign, test, or upload an app to Google Play.

1. Install Node.js and Android Studio on a computer.
2. Copy your generated game's index.html, CSS, JavaScript and asset folders into this folder's www/ directory. Keep relative file paths intact.
3. Change appId in capacitor.config.json to a unique reverse-domain ID you control (for example, com.yourstudio.yourgame). This ID becomes important after first publishing.
4. Change appName to your game's title.
5. Open a terminal in this folder and run:
     npm install
     npx cap add android
     npx cap sync android
     npx cap open android
6. In Android Studio, test the game on devices/emulators, fix layout and performance issues, and create a signed Android App Bundle (.aab) using the release build workflow.
7. Review the current Google Play Console requirements, complete store listing, content rating, privacy/data-safety declarations and required testing, then upload the signed AAB.

Never share signing keys or passwords. Keep a secure backup of the signing key. Google Play package IDs are permanent once used. Do not publish a game until you own or have permission to use every asset, sound, font and piece of code it contains.
